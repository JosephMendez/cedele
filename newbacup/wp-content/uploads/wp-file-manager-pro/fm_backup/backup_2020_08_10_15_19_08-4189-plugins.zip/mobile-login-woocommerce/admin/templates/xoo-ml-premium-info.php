<div class="xoo-wsc-prem">
	<div class="xoo-hero-btns">	
		<a class="live-demo button button-primary button-hero" href="http://xootix.com/plugins/mobile-login-for-woocommerce/">BUY PREMIUM - 9$</a>
	</div>
	<h1 style="margin-top: 35px; text-align: center;">Looks more cool with our popup design. <a href="http://demo.xootix.com/mobile-login-for-woocommerce/">Live Demo</a></h1>
</div>