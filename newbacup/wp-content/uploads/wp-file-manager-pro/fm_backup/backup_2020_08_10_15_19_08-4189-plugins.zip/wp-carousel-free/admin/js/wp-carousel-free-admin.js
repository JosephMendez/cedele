jQuery(document).ready(function ($) {

    /**
     * Admin Preloader.
     */
    $(".sp_wpcp_shortcode_generator .spf-wrapper").css("visibility", "hidden");
    $(".sp_wpcp_shortcode_generator .spf-wrapper").css("visibility", "visible");
    $(".sp_wpcp_shortcode_generator .spf-wrapper li").css("opacity", 1);
});