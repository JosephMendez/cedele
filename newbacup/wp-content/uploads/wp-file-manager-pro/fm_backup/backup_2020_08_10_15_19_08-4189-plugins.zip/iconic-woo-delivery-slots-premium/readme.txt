=== WooCommerce Delivery Slots ===
Contributors: iconicwp
Requires at least: 4.7
Tested up to: 5.4
Stable tag: trunk