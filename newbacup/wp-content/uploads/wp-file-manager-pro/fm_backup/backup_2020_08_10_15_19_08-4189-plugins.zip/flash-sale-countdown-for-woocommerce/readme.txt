=== Sale Countdown WooCommerce ===
Contributors: Tomiup
Tags: flash sale, countdown, flash sale countdown, WooCommerce sale countdown
Donate link:
Requires at least: 4.8.2
Tested up to: 5.4
Requires PHP: 5.6
Stable tag: trunk
License: GPLv2 or later

Display flash sale with countdown timer, display sale-flash in percentage

== Description ==
Display flash sale with countdown timer, display sale-flash in percentage


This plugin is addon for WooCommerce plugin.


== Features ==
* Display flash sale with countdown timer.
* Display sale-flash in percentage.


== Installation ==
1. Upload the plugin files to the "/wp-content/plugins/flash-sale-countdown-for-woocommerce/" directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the "Plugins" screen in WordPress.

== Screenshots ==
1. screenshot-1.png
2. screenshot-2.png
3. screenshot-3.png

== Changelog ==
= 1.0.0 =
* Initial Release.

== Upgrade Notice ==
= 1.0.0 =
* Initial Release.