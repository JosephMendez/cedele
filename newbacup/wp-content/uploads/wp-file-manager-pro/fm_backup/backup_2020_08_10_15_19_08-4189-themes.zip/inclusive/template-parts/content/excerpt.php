<?php
/**
 * Template part for displaying excerpts.
 *
 * @package Inclusive
 * @since 1.0.0
 */

?>

<div class="entry-summary">
	<?php the_excerpt(); ?>
</div><!-- .entry-summary -->
