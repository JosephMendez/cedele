<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.css">
<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">

<?php
    global $wpdb;
    $placeholder = get_option('cdls_placeholder', 'Free deliveries for order above 80$');
    
    $central_kitchen = $wpdb->get_row("SELECT id FROM wp_store_location WHERE central_kitchen = 1");

    $holidays = $wpdb->get_results("SELECT start_date, end_date FROM `wp_store_holiday` WHERE id in (SELECT holiday_id FROM wp_store_holiday_related WHERE store_id = $central_kitchen->id)");

    $date_working = $wpdb->get_results("SELECT start_working_time, end_working_time, working_day from wp_store_working_time WHERE store_id = $central_kitchen->id");

    $deliveryStartTime = get_option('delivery_start_time');

    $deliverySlotDuration = get_option('delivery_slot_duration');

    $deliveryGapTime = get_option('delivery_gap_time');

    $cutOffTime = get_option('cot_delivery');
?>
<div class="delivery">
    <div class="delivery-form d-flex">
        <img src="<?php echo get_template_directory_uri(); ?>/images/pin.svg" alt="Pin">
        <label class="ml-3">Select how the food will be delivered</label>
    </div>
    <div class="select-delivery d-flex mt-3">
        <div class="d-flex align-items-center delivery-method">
            <input name="select-delivery" type="radio" value="delivery" checked/>
            <label class="ml-2">Delivery</label>
        </div>
        <div class="d-flex align-items-center self-collection-method">
            <input name="select-delivery" type="radio" value="self-collection"/>
            <label class="ml-2">Self Collection</label>
        </div>
    </div>
    <input type="text" placeholder="<?php echo $placeholder ?>" class="mt-2 delivery-input-search" id="delivery-input-search"/>

    <div class="delivery-choose-time mt-3">
        <div class="d-flex">
            <img src="<?php echo get_template_directory_uri(); ?>/images/clock.svg" alt="">
            <label class="ml-2">Choose a delivery time</label>
        </div>
        <div class="d-flex mt-2 justify-content-between">
            <div class="delivery-date-start">
                <input readonly type="text" name="delivery-time-select-start" id="delivery-time-select-start" class="delivery-time-select-start" />
                <img id="btn-arrow-down-select-date" src="<?php echo get_template_directory_uri(); ?>/images/arrow-down.svg" />
            </div>
            <div class="delivery-time">
                <select name="select-time" id="select-time-picker">
                    
                </select>
                <!-- <input type="text" id="delivery-time-picker" name="delivery-time-picker" class="delivery-time-picker"> -->
                <!-- <img id="btn-arrow-down-select-time" src="<?php echo get_template_directory_uri(); ?>/images/arrow-down.svg" /> -->
            </div>
        </div>
    </div>
</div>
<script src="//cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-dateFormat/1.0/jquery.dateFormat.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/datepicker/1.0.9/datepicker.min.js"></script>
<script src="https://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
<script src="https://cdn.jsdelivr.net/npm/date-and-time/date-and-time.min.js"></script>

<script type="text/javascript">
    const apikey = 'AIzaSyDUszlOcJdlRnOuxa97pVs_uT_GLJO07qc';
    jQuery(document).ready(function() {
        const dateWorkingEncode = <?php echo json_encode($date_working) ?>

        const holidaysEncode = <?php echo json_encode($holidays) ?>

        const deliveryStartTime = <?php echo $deliveryStartTime ?>

        const deliverySlotDuration = <?php echo $deliverySlotDuration ?>

        const deliveryGapTime = <?php echo $deliveryGapTime ?>

        const cutOffTime = <?php echo $cutOffTime ?>

        let dateHolidays = [];

        let dayNameFocus = '';

        holidaysEncode.forEach(function(h, index) {
            let dates = []
            const endDate = new Date(h.end_date);
            //to avoid modifying the original date
            const theDate = new Date(h.start_date)
            while (theDate < endDate) {
                dates = [...dates, new Date(theDate)]
                theDate.setDate(theDate.getDate() + 1)
            }

            dates = [...dates, endDate];
            dateHolidays = dateHolidays.concat(dates);
        });

        let dateFormatHoliday = [];

        dateHolidays.forEach(function (item, index) {
            dateFormatHoliday.push(date.format(item, 'YYYY-M-D', true));
        });

        const parseDate = [
            'monday',
            'tuesday',
            'wednesday',
            'thursday',
            'friday',
            'saturday',
            'sunday'
        ];

        let dateOfWeekTodayString = new Date().toLocaleString('en-us', {  weekday: 'long' }).toLowerCase();

        let dateTodayWorking = dateWorkingEncode.find(d => d.working_day == dateOfWeekTodayString);

        const dateWorkingArr = dateWorkingEncode.map(item => item['working_day']);

        let different = parseDate.filter(x => !dateWorkingArr.includes(x));
        
        const parseDateByKey = {
            'monday': 1,
            'tuesday': 2,
            'wednesday': 3,
            'thursday': 4,
            'friday': 5,
            'saturday': 6,
            'sunday': 0,
        };

        const keyDateDisable = [];

        if (different.length) {
            different.forEach(function(item, index) {
                keyDateDisable.push(parseDateByKey[item]);
            });
        };

        const formatDate = "ddd, dd MMM";
        const dateData = jQuery('#delivery-date-picker').val() || new Date();
        jQuery('#delivery-time-select-start').val(jQuery.format.date(dateData, formatDate));
        jQuery('#delivery-time-select-start').datepicker({
            minDate: new Date(),
            onSelect: function(dateText) {
                dayNameFocus = new Date(dateText).toLocaleString('en-us', {  weekday: 'long' }).toLowerCase();
                let data = dateWorkingEncode.find(d => d.working_day == dayNameFocus);
                let startTime = convertStartTime(data.start_working_time.split(':'), deliveryStartTime, deliverySlotDuration);
                let endTime = convertEndtime(data.end_working_time.split(':'), cutOffTime);
                jQuery('#select-time-picker').html(get_options(startTime, endTime));
                jQuery('#delivery-time-select-start').val(jQuery.format.date(new Date(dateText), formatDate));
            },

            beforeShowDay: function(date) {
                let day = date.getDay();
                let dat = date.getDate();
                let year = date.getFullYear();
                let month = date.getMonth() + 1;
                let fullDate = year + '-' + month + '-' + dat;

                if (jQuery.inArray(fullDate, dateFormatHoliday) != -1) {
                    return [false, ''];
                } else
                if (keyDateDisable.includes(date.getDay())) {
                    return [false, '']
                } else {
                    return [true, '']
                }
            }
        });

        let timeStartWorking = dateTodayWorking.start_working_time.split(':');
        let timeEndWorking = dateTodayWorking.end_working_time.split(':');

        function convertEndtime(timeEndWorking, cutOffTime) {
            timeEndWorkingMinute = parseInt(timeEndWorking[1]) - parseInt(cutOffTime);

            if (timeEndWorkingMinute < 0) {
                timeEndWorking[1] = 60 + timeEndWorkingMinute;

                if (cutOffTime < 60) {
                    timeEndWorking[0] = parseInt(timeEndWorking[0]) - 1; 
                }
            } else {
                timeEndWorking[1] = timeEndWorkingMinute;
            }

            return `${timeEndWorking[0]}:${timeEndWorking[1]}`;
        }

        function convertStartTime(timeArray, deliveryStartTime, deliverySlotDuration) {
            timeArray.pop();
            let mmTimeStart = parseInt(timeArray[1]) + parseInt(deliveryStartTime);


            timeArray[0] = parseInt(timeArray[0]) + parseInt(Math.floor(mmTimeStart / 60));

            timeArray[1] = mmTimeStart % 60;

            let mmTimeEnd = [];
            mmTimeEnd[0] = parseInt(timeArray[0]) + parseInt(Math.floor(parseInt(mmTimeStart + deliverySlotDuration) / 60))

            mmTimeEnd[1] = parseInt(mmTimeStart + deliverySlotDuration) % 60;

            if (timeArray[0] < 10) {
                timeArray[0] = '0' + timeArray[0];
            }

            if (mmTimeEnd[0] < 10) {
                mmTimeEnd[0] = '0' + mmTimeEnd[0];
            }

            return `${timeArray[0]}:${timeArray[1]}`
        }

        // timeStartWorking.pop();

        // let mmTimeStart = parseInt(timeStartWorking[1]) + parseInt(deliveryStartTime);


        // timeStartWorking[0] = parseInt(timeStartWorking[0]) + parseInt(Math.floor(mmTimeStart / 60));

        // timeStartWorking[1] = mmTimeStart % 60;

        // let mmTimeEnd = [];
        // mmTimeEnd[0] = parseInt(timeStartWorking[0]) + parseInt(Math.floor(parseInt(mmTimeStart + deliverySlotDuration) / 60))

        // mmTimeEnd[1] = parseInt(mmTimeStart + deliverySlotDuration) % 60;

        // if (timeStartWorking[0] < 10) {
        //     timeStartWorking[0] = '0' + timeStartWorking[0];
        // }

        // if (mmTimeEnd[0] < 10) {
        //     mmTimeEnd[0] = '0' + mmTimeEnd[0];
        // }

        

        let timeEndWorkingMinute = parseInt(timeEndWorking[1]) - parseInt(cutOffTime);

        if (timeEndWorkingMinute < 0) {
            timeEndWorking[1] = 60 + timeEndWorkingMinute;

            if (cutOffTime < 60) {
                timeEndWorking[0] = parseInt(timeEndWorking[0]) - 1; 
            }
        } else {
            timeEndWorking[1] = timeEndWorkingMinute;
        }

        timeEndWorking = `${timeEndWorking[0]}:${timeEndWorking[1]}`;

        jQuery('.ui-timepicker-container').addClass('time-picker');

        jQuery('#delivery-input-search').on('keyup', function() {
            const addr = jQuery(this).val().trim();
            if (addr.length >= 3) {
                let lat;
                let long;
                jQuery.ajax({
                    url: `https://maps.googleapis.com/maps/api/geocode/json?address=${addr}&key=${apikey}`,
                    type : 'get',
                    dataType: 'json',
                    success: function(data) {
                        if (data.status == 'OK' && data.results.length) {
                            lat = data.results[0].geometry.location.lat;
                            long = data.results[0].geometry.location.lng;
                            
                            jQuery.ajax({
                                url: `https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=21.027907,105.785698&radius=1500&keyword=cruise&key=AIzaSyDUszlOcJdlRnOuxa97pVs_uT_GLJO07qc`,
                                method: 'GET',
                                dataType: 'json',
                                success: function(data) {
                                    if  (data.results.length) {
                                        console.log(data.results);
                                    }
                                }
                            });
                        }
                    }
                })
            }
        });

        jQuery('#btn-arrow-down-select-date').on('click', function() {
            jQuery('#delivery-time-select-start').datepicker("show");
        });

        jQuery('#select-time-picker').append(get_options(`${timeStartWorking[0]}:${timeStartWorking[1]}`, `${timeEndWorking}`));

        function get_options(startTime, endTime) {
            const today = new Date();
            const minute = today.getMinutes() < 10 ? ('0' + today.getMinutes()) : today.getMinutes();
            let currentTime = today.getHours() + ":" + minute;
            html = '';
            newStartTime = startTime;
            newEndTime = startTime;
            duration = deliverySlotDuration;
            gapTime = deliveryGapTime;

            while (newEndTime < endTime) {
                newEndTime = sum_two_time_end(newStartTime, duration);
                if (newEndTime > endTime) {
                    newEndTime = endTime
                } else if (newStartTime > currentTime) {
                    html+= `<option>${newStartTime} - ${newEndTime}</option>`;
                }

                newStartTime = sum_two_time_start(newStartTime, gapTime)
            }
            return html;
        }

        function sum_two_time_start(startTimeSlot, gapTime) {
            let st = startTimeSlot.split(':');

            let time = parseInt(st[1]) + parseInt(gapTime);

            st[0] = parseInt(st[0]) + parseInt(Math.floor(time / 60));

            st[1] = time % 60;

            if (st[0] < 10) {
                st[0] = '0' + st[0];
            }

            if (st[1] < 10) {
                st[1] = '0' + st[1];
            }

            return `${st[0]}:${st[1]}`;
        }

        function sum_two_time_end(endTimeSlot, duration) {
            let st = endTimeSlot.split(':');

            let time = parseInt(st[1]) + parseInt(duration);

            st[0] = parseInt(st[0]) + parseInt(Math.floor(time / 60));

            st[1] = time % 60;

            if (st[0] < 10) {
                st[0] = '0' + st[0];
            }

            if (st[1] < 10) {
                st[1] = '0' + st[1];
            }

            return `${st[0]}:${st[1]}`;
        }
    })
</script>

<style>
    .delivery-input-search::-webkit-input-placeholder { /* WebKit, Blink, Edge */
        color: #AAAAAA;
    }
    .delivery-input-search:-moz-placeholder { /* Mozilla Firefox 4 to 18 */
        color: #AAAAAA;
    }
    .delivery-input-search::-moz-placeholder { /* Mozilla Firefox 19+ */
        color: #AAAAAA;
    }
    .delivery-input-search:-ms-input-placeholder { /* Internet Explorer 10-11 */
        color: #AAAAAA;
    }
    .delivery-input-search::-ms-input-placeholder { /* Microsoft Edge */
        color: #AAAAAA;
    }
    .delivery-input-search::placeholder { /* Most modern browsers support this now. */
        color: #AAAAAA;
    }
    .time-picker {
        z-index: 11!important;
    }
    .delivery {
        position: absolute;
        left: 28%;
        padding: 20px 30px;
        width: 730px;
        background: #FFFFFF;
        box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
        border-radius: 4px;
        z-index: 10;
        bottom: 32%;
    }

    .delivery-form label {
        font-family: Berthold Akzidenz Grotesk BE;
        font-style: normal;
        font-weight: bold;
        font-size: 20px;
        line-height: 28px;
        margin-bottom: 0;

        /* identical to box height, or 140% */

        letter-spacing: 0.15px;

        /* Grayshade/3f3f3f */

        color: #3F3F3F;
    }

    .select-delivery label {
        font-family: Roboto;
        font-style: normal;
        font-weight: 500;
        font-size: 14px;
        line-height: 22px;
        /* identical to box height, or 157% */

        letter-spacing: 0.1px;
        margin-bottom: 0;

        /* Primary/Brown */

        color: #914204;
    }

    .select-delivery input {
        height: 30px;
        width: 16px;
    }

    .self-collection-method {
        margin-left: 61px;
    }

    input[type='radio'] {
        -webkit-appearance: none;
        width: 20px;
        height: 20px;
        border-radius: 50%;
        outline: none;
        border: 2px solid #914204;
    }

    input[type='radio']:before {
        content: '';
        display: block;
        width: 60%;
        height: 60%;
        margin: 20% auto;
        border-radius: 50%;
    }

    input[type="radio"]:checked:before {
        background: #914204;

    }

    input[type="radio"]:checked {
        border-color: #914204;
    }

    .delivery-input-search {
        background: #FFFFFF;
        /* Grayshade/3f3f3f */

        border: 1px solid #3F3F3F;
        box-sizing: border-box;
        border-radius: 4px;
        width: 100%;
        height: 48px;
        text-indent: 15px;
        font-size: 14px;
    }

    .delivery-choose-time label {
        font-family: Berthold Akzidenz Grotesk BE;
        font-style: normal;
        font-weight: bold;
        font-size: 20px;
        line-height: 28px;
        /* identical to box height, or 140% */

        letter-spacing: 0.15px;

        /* Grayshade/3f3f3f */

        color: #3F3F3F;
        margin-bottom: 0;
    }

    #delivery-time-select-start {
        cursor: pointer;
        border-radius: 3px;
        height: 36px;
        width: 100%;
        background: #fff;
        text-align-last: center;
        font-family: Roboto;
        font-style: normal;
        font-weight: 500;
        font-size: 14px;
        line-height: 22px;
        border: 1px solid;
        /* identical to box height, or 157% */

        text-align: center;
        letter-spacing: 0.1px;

        /* Grayshade/3f3f3f */

        color: #3F3F3F;
    }

    .delivery-time-select-start option {
        text-align: center;
    }

    .delivery-date-start {
        width: 45%;
        position: relative;
        display: flex;
        align-items: center;
    }

    .delivery-time {
        width: 45%;
        position: relative;
        display: flex;
        align-items: center;
    }

    .delivery-date-start img {
        position: absolute;
        right: 12px;
        cursor: pointer;
    }

    #select-time-picker {
        -webkit-appearance: none;
        cursor: pointer;
        border-radius: 3px;
        height: 36px;
        width: 100%;
        background: #fff;
        text-align-last: center;
        font-family: Roboto;
        font-style: normal;
        font-weight: 500;
        font-size: 14px;
        line-height: 22px;
        border: 1px solid;
        text-align: center;
        letter-spacing: 0.1px;
        color: #3F3F3F;
        background: url('<?php echo get_template_directory_uri(); ?>/images/arrow-down.svg') 96% / 5% no-repeat;
    }

    .delivery-time img {
        position: absolute;
        right: 12px;
        cursor: pointer;
    }

    #delivery-date-picker {
        border-radius: 3px;
        height: 36px;
        width: 45%;
        background: #fff;
        text-align-last: center;
        font-family: Roboto;
        font-style: normal;
        font-weight: 500;
        font-size: 14px;
        line-height: 22px;
        border: 1px solid;
        /* identical to box height, or 157% */

        text-align: center;
        letter-spacing: 0.1px;

        /* Grayshade/3f3f3f */

        color: #3F3F3F;
    }
</style>