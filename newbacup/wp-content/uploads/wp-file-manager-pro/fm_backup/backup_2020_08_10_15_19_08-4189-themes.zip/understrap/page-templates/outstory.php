<?php
/**
 * Template Name: OurStory
 *
 * @package UnderStrap
 */

// Exit if accessed directly.
defined('ABSPATH') || exit;

get_header();
?>
<?php
$banner_ourStory1 = wp_get_attachment_image_src(get_option('sdls_out_story_image1'), 'full');
$banner_ourStory2 = wp_get_attachment_image_src(get_option('sdls_out_story_image2'), 'full');
?>

<?php


$post_cedele = 991;
$post_workspace = 998;
$post_toss = 1003;
$post_chiak = 1008;
$post_slide = 1018;
?>
	<style>
		.container-fluid {
			margin: 0 auto;
			padding: 0;
		}

		.title, a {
			font-family: Berthold Akzidenz Grotesk BE, serif;
			font-style: normal;
			font-weight: bold;
			line-height: 46px;
			letter-spacing: 0.005em;
			color: #3C1605;
		}

		.row_div {
			width: 100%;
			padding: 2em;
			background: url("<?php echo $banner_ourStory2[0]; ?>");
		}

		.col_div {
			background: #FFFFFF;
			/* Small */
			box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
			border-radius: 4px;
			margin-left: 1.2em;
			padding: 10px 0 10px 0;
			text-align: center;
		}

		section {
			width: inherit;
			padding: 1em 0 1em 0;
			/*min-height: 400px;*/
		}

		p {
			font-family: Plantin MT Pro, serif;
			font-style: normal;
			font-weight: normal;
			font-size: 16px;
			line-height: 24px;
			letter-spacing: 0.44px;
			color: #000000;
		}

		#section_work p {
			font-family: Plantin MT Pro, serif;
			font-style: normal;
			font-weight: normal;
			font-size: 16px;
			line-height: 24px;
			letter-spacing: 0.44px;
			color: #FFFFFF;
			text-align: left;
		}

		.btn-outline-warning {
			color: #AD8850;
			border-color: #AD8850;;
		}

		#section_work {
			background: #3F3F3F;
			padding: 3em;
		}

		#tolds {
			background: #F3F3F3;
		}

		#cedele, #tolds, #child, #section_work {
			min-height: 607px;
			padding: 3em;
		}

		.chiak_img_left {
			position: absolute;
			left: 0;
		}

		.chiak_img_right {
			position: absolute;
			left: 53%;
			right: 0;
		}

		#section_work {
			min-height: 607px;
		}

		.img_top {
			position: absolute;
			top: 0;
		}

		.img_bottom {
			position: absolute;
			bottom: 0;
			top: 74%
		}

		.img_right {
			position: absolute;
			left: 45%;
		}

		.img_rigth_2 {
			position: absolute;
			right: 0;
			left: 56%;
		}

		.img_bottom_2 {
			position: absolute;
			bottom: 0;
			left: 14px;
			right: 0;
			top: 75%;
		}

		.img_bottom_3 {
			position: absolute;
			top: 100%;
		}

		.img_bottom_4 {
			position: absolute;
			top: 100%;
			left: 39%;
		}

		}
		@media only screen
		and (min-device-width: 320px)
		and (max-device-width: 480px) {
			.img_top, .img_bottom, .img_right, .img_rigth_2, .img_bottom_2.img_bottom_3, .img_bottom_4, .chiak_img_right, .chiak_img_left {
				width: 100%;
				margin-bottom: 1em;
			}
		}
	</style>

	<img class="hero-banner" src="<?php echo $banner_ourStory1[0]; ?>"/>
	<article class="container-fluid">
		<section>
			<div class="container" style="padding-left:12%;padding-right:12%">
				<div class="row">

					<div class="col-md-6 col-sm-12 col-xs-12">
						<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
							<div class="carousel-inner">
									<div class="carousel-item">
										<img class="d-block w-100"
											 src="<?php echo get_site_url() . '/wp-content/uploads/2020/08/Img.png' ?>"
											 alt="First slide">
									</div>
									<div class="carousel-item active">
										<img class="d-block w-100"
											 src="<?php echo get_site_url() . '/wp-content/uploads/2020/08/Img.png'?>"
											 alt="Second slide">
									</div>
									<div class="carousel-item">
										<img class="d-block w-100"
											 src="<?php echo get_site_url() . '/wp-content/uploads/2020/08/Img.png'?>"
											 alt="Third slide">
									</div>
							</div>
							<a class="carousel-control-prev" href="#carouselExampleControls" role="button"
							   data-slide="prev">
								<span class="carousel-control-prev-icon" aria-hidden="true"></span>
								<span class="sr-only">Previous</span>
							</a>
							<a class="carousel-control-next" href="#carouselExampleControls" role="button"
							   data-slide="next">
								<span class="carousel-control-next-icon" aria-hidden="true"></span>
								<span class="sr-only">Next</span>
							</a>
						</div>
					</div>
					<div class="col-md-6 col-sm-12 col-xs-12">
						<?php  $post = get_post($post_slide);?>
						<a href="<?php echo $post->guid?>"><h3><?php echo $post->post_title ?></h3>
						</a>
						<p><?php echo $post->post_content?></p>
					</div>
				</div>

			</div>
		</section>
		<section class="row_div">
			<div class="container" style="padding-left:12%;padding-right:12%">
				<div class="row">
					<div class="col-4">
						<h3 class="title">Our Brands</h3>
					</div>
				</div>
				<div class="row">

					<div class="col col_div">
						<a href="#cedele">
							<img src="<?php echo get_site_url() . '/wp-content/uploads/2020/08/image-2.png' ?>"
								 alt="" class="img-responsive">
						</a>
					</div>
					<div class="col col_div">
						<a href="#section_work"><img
								src="<?php echo get_site_url() . '/wp-content/uploads/2020/08/image-3.png' ?>"
								alt="" class="img-responsive"></a>
					</div>
					<div class="col col_div">
						<a href="#tolds">
							<img src="<?php echo get_site_url() . '/wp-content/uploads/2020/08/anh3.png' ?>"
								 alt="" class="img-responsive">
						</a>

					</div>
					<div class="col col_div">
						<a href="#child">
							<img src="<?php echo get_site_url() . '/wp-content/uploads/2020/08/anh4.png' ?>"
								 alt="" class="img-responsive">
						</a>
					</div>
				</div>
			</div>
		</section>
		<section id="cedele">
			<div class="container" style="padding-left:12%;padding-right:12%">
				<div class="row">
					<div class="col-md-7 col-xs-12 col-sm-12">
						<img src="<?php echo get_site_url() . '/wp-content/uploads/2020/08/image-2.png' ?>"
							 alt="" class="img-responsive">
						<?php $post_7 = get_post($post_cedele); ?>

						<p>
							<?php echo($post_7->post_content); ?>
						</p>

					</div>
					<div class="col-md-5 col-xs-12 col-sm">
						<?php
						if (class_exists('Dynamic_Featured_Image')):
							global $dynamic_featured_image;
							$featured_images = $dynamic_featured_image->get_featured_images($post_cedele);
							if ($featured_images):
								?>
								<img src="<?php echo $featured_images[0][full] ?>"
									 class="img_top img-responsive"
									 alt="">
								<img src="<?php echo $featured_images[1][full] ?>" alt=""
									 class="img_right img-responsive">
								<img src="<?php echo $featured_images[2][full] ?>" alt=""
									 class="img_bottom img-responsive">
							<?php
							endif;
						endif;
						?>
					</div>
				</div>

			</div>
		</section>

		<section id="section_work">
			<div class="container" style="padding-left:12%;padding-right:12%">
				<div class="row">
					<div class="col-md-6 col-xs-12 col-sm-12">
						<?php
						if (class_exists('Dynamic_Featured_Image')):
							global $dynamic_featured_image;
							$featured_images = $dynamic_featured_image->get_featured_images($post_workspace);
							if ($featured_images):
								?>
								<img src="<?php echo $featured_images[0][full] ?>"
									 class="img-responsive"
									 alt="">
								<img src="<?php echo $featured_images[1][full] ?>"
									 alt=""
									 class="img_rigth_2 img-responsive">
								<img src="<?php echo $featured_images[2][full] ?>"
									 alt=""
									 class="img_bottom_2 img-responsive">
							<?php
							endif;
						endif;
						?>
					</div>
					<div class="col-md-6 col-xs-12 col-sm">
						<img src="<?php echo get_site_url() . '/wp-content/uploads/2020/08/workkk.png' ?>"
							 alt="" class="img-responsive">
						<?php $post_7 = get_post($post_workspace); ?>

						<p>
							<?php echo($post_7->post_content); ?>
						</p>
						<br>
						<a href="<?php echo get_site_url() . '/workspace/' ?>" class="btn btn-outline-warning">LEARN
							MORE</a>
					</div>
				</div>
			</div>
		</section>
		<section id="tolds">
			<div class="container" style="padding-left:12%;padding-right:12%">
				<div class="row">
					<div class="col-md-6 col-xs-12 col-sm-12">
						<img src="<?php echo get_site_url() . '/wp-content/uploads/2020/08/tolds.png' ?>"
							 alt="" class="">
						<br>
						<br>
						<?php $post_7 = get_post($post_toss); ?>
						<p>
							<?php echo($post_7->post_content); ?>
						</p>
					</div>
					<div class="col-md-6 col-xs-12 col-sm">
						<?php
						if (class_exists('Dynamic_Featured_Image')):
							global $dynamic_featured_image;
							$featured_images = $dynamic_featured_image->get_featured_images($post_toss);
							if ($featured_images):
								?>
								<img src="<?php echo $featured_images[0][full] ?>"
									 class=" img_top img-responsive"
									 alt="">
								<img src="<?php echo $featured_images[1][full] ?>"
									 alt=""
									 class="img_bottom_3 img-responsive">
								<img src="<?php echo $featured_images[2][full] ?>"
									 alt=""
									 class="img_bottom_4 img-responsive">
							<?php
							endif;
						endif;
						?>

					</div>
				</div>
			</div>
		</section>
		<section id="child">
			<div class="container" style="padding-left:12%;padding-right:12%">
				<div class="row">
					<div class="col-md-6 col-xs-12 col-sm-12">

						<?php
						if (class_exists('Dynamic_Featured_Image')):
							global $dynamic_featured_image;
							$featured_images = $dynamic_featured_image->get_featured_images($post_chiak);
							if ($featured_images):
								?>
								<img src="<?php echo $featured_images[0][full] ?>"
									 class=" chiak_img_left img-responsive"
									 alt="">
								<img src="<?php echo $featured_images[1][full] ?>"
									 alt=""
									 class="chiak_img_right img-responsive">
							<?php
							endif;
						endif;
						?>

					</div>
					<div class="col-md-6 col-xs-12 col-sm">
						<img src="<?php echo get_site_url() . '/wp-content/uploads/2020/08/chiak.png' ?>"
							 alt="" class="">
						<br>
						<br>
						<?php $post_7 = get_post($post_chiak); ?>

						<p>
							<?php echo($post_7->post_content); ?>
						</p>
					</div>
				</div>
			</div>
		</section>
	</article>
<?php
get_footer();
