<?php 
    global $wpdb;

    $central_kitchen = $wpdb->get_row("SELECT * FROM wp_store_location WHERE central_kitchen = 1");
?>
<div class="container cedele-footer">
    <div class="row cedele-footer-content">
        <div class="col-md-6 cedele-footer-left pl-0">
            <div class="row">
                <div class="col-md-6 cedele-footer-central-kitchen">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/cedele-footer.svg" width="120px" />
                    <p>
                        <?php echo $central_kitchen->store_name . ', ' . $central_kitchen->number_house . ', ' . $central_kitchen->street_name . ', ' . $central_kitchen->zipcode ?>
                        <br />
                        Tel: <?php echo $central_kitchen->phone_number ?>
                    </p>
                </div>
                <div class="col-md-6">
                    <div class="cedele-footer-quick-link text-white">
                        QUICK LINK
                    </div>
                    <div class="cedele-footer-link text-white">
                        <a class="text-white" href="#">Our Story</a>
                    </div>
                    <div class="cedele-footer-link">
                        <a class="text-white" href="#">FAQ</a>
                    </div>
                    <div class="cedele-footer-link text-white">
                        <a class="text-white" href="#">Order Terms & Delivery Charges</a>
                    </div>
                    <div class="cedele-footer-link text-white">
                        <a class="text-white" href="#">Privacy Policy</a>
                    </div>
                    <div class="cedele-footer-link text-white">
                        <a class="text-white" href="#">Contact us</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6 cedele-footer-right pl-5">
            <p>SUBSCRIBE TO OUR NEWSLETTER</p>
            <div class="cedele-footer-email d-flex m2-5">
                <input type="text" id="cedele-footer-email-input-search" placeholder="&nbsp; &nbsp;Enter your Email"/>
                <input type="button" id="cedele-footer-email-subscribe" value="SUBSCRIBE">
            </div>
            <p class="mt-4">STAY CONNECTED</p>
            <div class="d-flex cedele-footer-list-icon">
                <a href="https://www.facebook.com/cedelesingapore/"><img class="ml-1" src="<?php echo get_template_directory_uri(); ?>/images/footer-fb.svg"/></a>
                <a href="https://www.instagram.com/cedelesingapore/"><img class="ml-3" src="<?php echo get_template_directory_uri(); ?>/images/footer-ig.svg"/></a>
            </div>
        </div>
    </div>
</div>

<style lang="css">
    .cedele-footer-central-kitchen p {
        font-family: Plantin MT Pro;
        font-style: normal;
        font-weight: normal;
        font-size: 13px;
        line-height: 22px;

        /* or 143% */
        letter-spacing: 0.25px;

        /* Grayshade/f3f3f3 */
        color: #F3F3F3;
        margin-top: 20px;
    }

    .cedele-footer-quick-link {
        font-family: Berthold Akzidenz Grotesk BE;
        font-style: normal;
        font-weight: bold;
        font-size: 14px;
        line-height: 17px;

        /* identical to box height */
        letter-spacing: 0.75px;
        text-transform: uppercase;
    }

    .cedele-footer-link {
        font-family: Plantin MT Pro;
        font-size: 13px;
        line-height: 24px;

        /* identical to box height, or 150% */
        letter-spacing: 0.44px;
        margin-top: 12px;
        cursor: pointer;
    }

    .cedele-footer-right {
        font-family: Berthold Akzidenz Grotesk BE;
        font-style: normal;
        font-weight: bold;
        font-size: 14px;
        line-height: 17px;

        /* identical to box height */
        letter-spacing: 0.75px;
        text-transform: uppercase;

        /* Grayshade/White */
        color: #FFFFFF;
    }

    #cedele-footer-email-input-search {
        background: inherit;
        border-radius: 5px;
        border: 1px solid #fff;
        color: #fff;
        height: 40px;
        min-width: 70%;
    }

    ::-webkit-input-placeholder { /* Edge */
        color: #fff;
        font-size: 12px;
    }

    :-ms-input-placeholder { /* Internet Explorer */
        color: #fff;
        font-size: 12px;
    }

    ::placeholder {
        color: #fff;
        font-size: 12px;
    }

    #cedele-footer-email-subscribe {
        background: #914204;

        /* Small */
        box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
        border-radius: 8px;
        border: navajowhite;
        height: 40px;
        margin-left: 14px;
        font-size: 14px;
        color: #fff;
        padding: 13px 15px;
        font-weight: bold;
    }

    @media only screen and (min-width: 320px) {
        .cedele-footer-right {
            padding-left: 0!important;
        }
    }
</style>