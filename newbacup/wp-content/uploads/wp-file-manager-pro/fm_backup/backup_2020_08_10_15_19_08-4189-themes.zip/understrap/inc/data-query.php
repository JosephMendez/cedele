<?php
/**
 * UnderStrap Data Helper
 *
 * @package UnderStrap
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

$table_store = $wpdb->prefix . 'store_location';
$table_master_data = $wpdb->prefix . 'store_master_data';
$table_working_time = $wpdb->prefix . 'store_working_time';
$table_holiday = $wpdb->prefix . 'store_holiday';
$table_store_holiday = $wpdb->prefix . 'store_holiday_related';

if ( ! function_exists( 'get_store_locations' ) ) {
  function get_store_locations() 
    {
      global $wpdb, $table_store;
      $results = $wpdb->get_results( "SELECT * FROM $table_store", OBJECT );
      return $results ? $results : [];
    }
}

if ( ! function_exists( 'get_master_data' ) ) {
  function get_master_data()
    {
      global $wpdb, $table_master_data;
      $result = $wpdb->get_results("SELECT * FROM $table_master_data", OBJECT );
      if ($result) {
        return $result;
      }
      return [];
    }
}

if ( ! function_exists( 'find_master_data' ) ) {
  function find_master_data($id)
    {
      global $wpdb, $table_master_data;
      $result = $wpdb->get_row("SELECT * FROM $table_master_data WHERE id = $id");
      if ($result) {
        return $result->data_name;
      }
      return '';
    }
}

if ( ! function_exists( 'get_working_time' ) ) {
  function get_working_time($id)
    {
      global $wpdb, $table_working_time;
      $result = $wpdb->get_results("SELECT * FROM $table_working_time WHERE store_id = $id", OBJECT);
      return $result;
    }
}

add_action( 'wp_ajax_list_store', 'get_list_store' );
add_action( 'wp_ajax_nopriv_list_store', 'get_list_store' );
function get_list_store() {
  global $wpdb, $table_store;

  $outlet = '';
  if (isset($_POST['outlet'])){
    $outlet = 'AND outlet_type = '.$_POST['outlet'];
  }

  if (isset($_POST['district'])) {
    $district = $_POST['district'];
    $results = $wpdb->get_results( "SELECT * FROM $table_store WHERE status = 1 AND district IN ($district) $outlet", OBJECT );
  } elseif (isset($_POST['area'])) {
    $area = $_POST['area'];
    $results = $wpdb->get_results( "SELECT * FROM $table_store WHERE status = 1 AND area IN ($area) $outlet", OBJECT );
  } else {
    $results = $wpdb->get_results( "SELECT * FROM $table_store WHERE status = 1 $outlet", OBJECT );
  }

  $items = array();
  foreach ($results as $key=>$location) {
    $last_time_order = get_option('last_time_order');
    $district = find_master_data($location->district);
    $area = find_master_data($location->area);
    $building = ($location->floor_unit || $location->building) ? ', '.$location->floor_unit.' '.$location->building : '';
    $working_time = get_working_time($location->id);
    $img = $location->image_id ? wp_get_attachment_image_src($location->image_id, 'medium') : '';
    $file = $location->file_id ? wp_get_attachment_url($location->file_id) : '#';
    
    $currentDay = strtolower(date('l'));
    
    $working_item_today = array_filter($working_time, function ($w) use ($currentDay) {
      return $w->working_day == $currentDay;
    });

    $last_order = count($working_item_today) > 0 ? $working_item_today[0]: null;

    if ($last_order->end_working_time !== '00:00:00') {
      $hours = floor($last_time_order/60);
      $minutes = $last_time_order % 60;
      if ($minutes < 10 && $minutes > 0) {
        $minutes = '0' . $minutes;
      };

      if ($hours < 10 && $hours > 0) {
        $hours = '0' . $hours;
      };
      $last_time_order = $hours . ':' . $minutes . ':00';
    }

    $last_time_order_to_time = strtotime($last_time_order);
    $end_time = strtotime($last_order->end_working_time);
    $data = ($end_time - $last_time_order_to_time) / 3600;

    $h = (floor($data) < 10 && floor($data) > 0) ? '0'. floor($data) : floor($data);

    $m = ( ($data-floor($data)) * 60 ) < 10 ? '0' . ( ($data-floor($data)) * 60 ) : ( ($data-floor($data)) * 60 );
    
    $last_order_finish = $h . ':' . $m;

    $item = (object) [
      'location' => $location,
      'district' => $district,
      'area' => $area,
      'img' => $img,
      'file' => $file,
      'working_time' => $working_time,
      'last_order' => $last_order_finish,
    ];
    array_push($items, $item);
  }

  wp_send_json_success(json_encode($items));

  die();
}