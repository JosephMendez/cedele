<?php
/**
 * UnderStrap enqueue scripts
 *
 * @package UnderStrap
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'understrap_scripts' ) ) {
	/**
	 * Load theme's JavaScript and CSS sources.
	 */
	function understrap_scripts() {
		// Get the theme data.
		$the_theme     = wp_get_theme();
		$theme_version = $the_theme->get( 'Version' );

		$css_version = $theme_version . '.' . filemtime( get_template_directory() . '/css/theme.min.css' );
		wp_enqueue_style( 'understrap-styles', get_template_directory_uri() . '/css/theme.min.css', array(), $css_version );
		wp_enqueue_style( 'cdl-google-fonts', '//fonts.googleapis.com/css?family=Roboto:wght@400;500&display=swap', false );

		wp_enqueue_script( 'jquery' );

		wp_enqueue_script( 'mCustomScrollbar', get_template_directory_uri() . '/js/jquery.mCustomScrollbar.concat.min.js', array(), '', true );
		wp_enqueue_script( 'select2js', get_template_directory_uri() . '/js/select2.full.min.js', array(), '', true );
		wp_enqueue_script( 'jConfirm', get_template_directory_uri() . '/js/jquery-confirm.min.js', array(), '', true );

		$js_version = $theme_version . '.' . filemtime( get_template_directory() . '/js/theme.min.js' );
		wp_enqueue_script( 'understrap-scripts', get_template_directory_uri() . '/js/theme.min.js', array(), $js_version, true );
		if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
			wp_enqueue_script( 'comment-reply' );
		}

		if ( is_page_template('page-templates/store-location.php') ) {
			wp_enqueue_script('googlemaps', '//maps.googleapis.com/maps/api/js?key=' . $GLOBALS['gmapKey'] . '&sensor=false', false, null, true);
			wp_enqueue_script('gmapjs', get_template_directory_uri() . '/js/gmap.min.js', null, null, true);
			wp_enqueue_script( 'lodashjs', get_template_directory_uri() . '/js/lodash.min.js', array(), '', true );
			wp_register_script(
				'store-location',
				get_template_directory_uri() . '/js/store-location.js',
				array( 'lodashjs', 'jquery' ),
				null, true
			);

			$localize = array(
			  'ajaxurl' => admin_url('admin-ajax.php'),
			  'auth' => wp_create_nonce('_check__ajax_100')
		 	);
		 	wp_localize_script('store-location', 'custom_ajax_vars', $localize);
		 	wp_enqueue_script('store-location');

		} 
	}
} // End of if function_exists( 'understrap_scripts' ).

add_action( 'wp_enqueue_scripts', 'understrap_scripts' );
