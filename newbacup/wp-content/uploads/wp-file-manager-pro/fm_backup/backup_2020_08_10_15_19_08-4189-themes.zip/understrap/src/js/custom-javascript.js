( function() {
  String.prototype.format = function () {
    var args = arguments;
    return this.replace(/\{\{|\}\}|\{(\d+)\}/g, function (m, n) {
      if (m == "{{") { return "{"; }
      if (m == "}}") { return "}"; }
      return args[n] ? args[n] : "";
    });
  }

  jQuery(document).ready(() => {
    jQuery('.cdl-scrollable').mCustomScrollbar({
      theme: 'dark'
    });
    jQuery('select.custom-select').select2({
      theme: 'bootstrap4',
      minimumResultsForSearch: Infinity,
    });

    var url = window.location.href;
    if(url.includes('my-account')) {
      jQuery('.woocommerce-form-register').parents('.u-column2').remove();
      if (jQuery('.woocommerce-form-login').length){
        jQuery('body').addClass('woocommerce-login');
      }
    }
    if(url.includes('register')) {
      jQuery('.woocommerce-form-login').parents('.u-column1').remove();
    }

    if (jQuery('.woo-quantity-edit').length){
      jQuery('body').on('click', '.woo-quantity-edit .qtt-plus', function(e) {
        e.preventDefault();
        e.stopPropagation();
        var productContainer = jQuery(this).parents('li.product');
        var qttInput = productContainer.find('.qtt-input');
        var cartButton = productContainer.find('.add-to-cart-container a');
        var qtt = parseInt(qttInput.val());
        qttInput.val(qtt+1);
        cartButton.attr('data-quantity', qtt+1);
      });
      jQuery('body').on('click', '.woo-quantity-edit .qtt-minus', function(e) {
        e.preventDefault();
        e.stopPropagation();
        var productContainer = jQuery(this).parents('li.product');
        var qttInput = productContainer.find('.qtt-input');
        var cartButton = productContainer.find('.add-to-cart-container a');
        var qtt = parseInt(qttInput.val());
        if (qtt > 1){
          qttInput.val(qtt-1);
          cartButton.attr('data-quantity', qtt-1);
        }
      });
    }

    jQuery(document.body).on('added_to_cart', function() {
      jQuery.ajax({
        type: 'POST',
        url: wc_add_to_cart_params.ajax_url,
        data: {
          'action': 'checking_cart_items',
          'added' : 'yes'
        },
        success: function (response) {
          if (response) {
            jQuery('#main-menu .menu-item.cart .badge').text(response);
            jQuery.alert({
              title: '',
              content: 'Added to Cart succesfully',
              icon: 'fa fa-check-circle text-success',
              autoClose: 5000,
              backgroundDismiss: true,
              bgOpacity: 0
            });
          }
        }
      });
    });

  });
})();