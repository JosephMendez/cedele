<?php
/**
 * UnderStrap functions and definitions
 *
 * @package UnderStrap
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

$GLOBALS['gmapKey'] = 'AIzaSyDUszlOcJdlRnOuxa97pVs_uT_GLJO07qc';

$understrap_includes = array(
	'/theme-settings.php',                  // Initialize theme default settings.
	'/setup.php',                           // Theme setup and custom theme supports.
	'/widgets.php',                         // Register widget area.
	'/enqueue.php',                         // Enqueue scripts and styles.
	'/template-tags.php',                   // Custom template tags for this theme.
	'/pagination.php',                      // Custom pagination for this theme.
	'/hooks.php',                           // Custom hooks.
	'/extras.php',                          // Custom functions that act independently of the theme templates.
	'/customizer.php',                      // Customizer additions.
	'/custom-comments.php',                 // Custom Comments file.
	'/jetpack.php',                         // Load Jetpack compatibility file.
	'/class-wp-bootstrap-navwalker.php',    // Load custom WordPress nav walker. Trying to get deeper navigation? Check out: https://github.com/understrap/understrap/issues/567.
	'/woocommerce.php',                     // Load WooCommerce functions.
	'/editor.php',                          // Load Editor functions.
	'/deprecated.php',                      // Load deprecated functions.
	'/data-query.php',
);

foreach ( $understrap_includes as $file ) {
	require_once get_template_directory() . '/inc' . $file;
}

function additional_product_tabs_metabox()
{
    add_meta_box(
        'add_product_metabox_additional_tabs',
        '
            <div class="product-availability" style="display:flex">
                <div class="product-availability-title">
                    Product availability
                </div>
            </div>
        ',
        'additional_product_tabs_metabox_content',
        'product',
        'advanced',
        'default',
        null
    );
}

function additional_product_tabs_metabox_content($post) {
    global $post;

    $typeChoosen = get_post_meta($post->ID, '_type', true);

    $listDay = [
        'monday' => __('Monday', 'woocommerce'),
        'tuesday' => __('Tuesday', 'woocommerce'),
        'wednesday' => __('Wednesday', 'woocommerce'),
        'thursday' => __('Thursday', 'woocommerce'),
        'friday' => __('Friday', 'woocommerce'),
        'saturday' => __('Saturday', 'woocommerce'),
        'sunday' => __('Sunday', 'woocommerce'),
    ];

    $checkedDate = get_post_custom($post->ID);

    if (empty($typeChoosen)) {
        $typeChoosen = 'daily-product';
    };

    $timeFrom = get_post_meta($post->ID, 'daily-product-available-time-from', true);
    $timeTo = get_post_meta($post->ID, 'daily-product-available-time-to', true);


    $oneDayTimeFrom = get_post_meta($post->ID, 'one-day-time-from', true);
    $oneDayTimeTo = get_post_meta($post->ID, 'one-day-time-to', true);

    $timeRangeFrom = get_post_meta($post->ID, 'time-range-from', true);
    $timeRangeTo = get_post_meta($post->ID, 'time-range-to', true);


    $oneDayDatepicker = get_post_meta($post->ID, 'one-day-date-picker');
    $dateRangeFrom = get_post_meta($post->ID, 'date-range-from');
    $dateRangeTo = get_post_meta($post->ID, 'date-range-to');
    $deliveryMethod = get_post_meta($post->ID, 'delivery_method');

    // product lead time
    $productLeadTime = get_post_meta($post->ID, 'product-lead-time-checkbox');
    $leadTimeMinutes = get_post_meta($post->ID, 'product-lead-time-minutes');
    $leadTimeDays = get_post_meta($post->ID, 'product-lead-time-days');

    // store location
    require_once __DIR__ . '/store_location.php';

    $list_stores = get_list_stores($post->ID);
    $list_option_stores = get_list_option_stores();
    ?>
        <div class="wp-product-avaiable product-availability-type-product">
            <b>Product frequently:</b>
            <input id="daily-product" type="radio" value="daily-product" name="product-avalability-type" onclick="checkDailyProduct()"/>
            <label>Normal Product</label>
            <input id="season-product" type="radio" name="product-avalability-type" value="season-product" onclick="checkSeasonProduct()"/>
            <label>Seasonal Product</label>
        </div>
        <input type="hidden" id="type-choosen" name="type-choosen" value="<?php echo $typeChoosen ?>" />
        <div class="wp-product-avaiable daily-product-info">
            <div class="wp-product-avaiable-sub">
                <div class="daily-product-available">
                    <label>Available day(s):</label>
                    <div class="daily-product-list-date-available" style="display:flex; margin-top:10px">
                        <?php
                            foreach($listDay as $key => $value) {
                                $existFieldType = get_post_meta($post->ID, '_type', true);
                                if (empty($existFieldType)) {
                                    echo '<div>
                                    <input type="checkbox" checked value="' .$key. '" name="' .$key. '"/>&nbsp;
                                        <label>' . $value . '</label>
                                    </div>&nbsp;&nbsp;';
                                }
                                else {
                                    echo '<div>
                                    <input type="checkbox" value="' .$key. '" name="' .$key. '"';
                                    ?>
                                    <?php
                                    if(isset($checkedDate[$key])) checked($checkedDate[$key][0], 'yes');
                                echo'/>&nbsp;
                                    <label>' . $value . '</label>
                                </div>&nbsp;&nbsp;';
                                }
                            }
                        ?>
                    </div>
                </div>

                <div class="daily-product-available" style="margin-top:30px">
                    <label>Available time:</label>
                    <div class="daily-product-available-time" style="margin-top:15px; display:flex">
                        <div class="daily-product-available-time-from" style="display:flex;align-items:center">
                            <label>From: </label>
                            <input name="daily-product-available-time-from" class="product-availability-timedatepicker" type="text" value="<?php echo $timeFrom !== '' ? $timeFrom : '00:00' ?>"/>
                        </div>
                        <div class="daily-product-available-time-to" style="margin-left:30px">
                            <label>To:</label>
                            <input name="daily-product-available-time-to" class="product-availability-timedatepicker" type="text" value="<?php echo $timeTo !== '' ? $timeTo : '23:59' ?>" />
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="wp-product-avaiable season-product-info">
            <div class="wp-product-avaiable-sub">
                <div class="season-product-available" style="display:flex; align-items:center">
                    <label>Available date(s):</label>
                    <div class="season-product-list-date-available" style="display:flex">
                        <select onchange="handleChangeType(this)" id="season-product-list-date-available-select" name="season-product-list-date-available-select" style="margin-left:10px">
                            <option id="one-day-only" value="one-day-only" name="one-day-only"> One Day Only </option>
                            <option id="time-range" value="time-range" name="time-range"> Time Range </option>
                        </select>
                        <input id="one-day-date-picker" type="date" value="<?php echo $oneDayDatepicker[0] ?>" name="one-day-date-picker" style="margin-left:10px;" required>
                        <div class="date-range-from" style="display:flex;align-items: center;margin-left:20px">
                            <label for="date-range-from">From:</label>
                            <input type="date" id="date-range-from" value="<?php echo $dateRangeFrom[0] ?>" name="date-range-from" style="margin-left:10px" required>
                        </div>
                        <div class="date-range-to" style="display:flex;align-items: center;margin-left:20px">
                            <label for="date-range-to">To:</label>
                            <input type="date" id="date-range-to" value="<?php echo $dateRangeTo[0] ?>" name="date-range-to" style="margin-left:10px" required>
                        </div>
                    </div>
                </div>

                <div class="season-product-available-one-day" style="margin-top:30px;">
                    <label>Available time:</label>
                    <div class="season-product-available-time" style="margin-top:15px; display:flex">
                        <div class="season-product-available-time-from" style="display:flex;align-items:center">
                            <label>From: </label>
                            <input name="one-day-time-from" class="product-availability-timedatepicker" type="text" value="<?php echo $oneDayTimeFrom !== '' ? $oneDayTimeFrom : '00:00' ?>"/>
                        </div>
                        <div class="season-product-available-time-to" style="margin-left:30px">
                            <label>To:</label>
                            <input name="one-day-time-to" class="product-availability-timedatepicker" type="text" value="<?php echo $oneDayTimeTo !== '' ? $oneDayTimeTo : '23:59' ?>"/>
                        </div>
                    </div>
                </div>

                <div class="season-product-available-time-range" style="margin-top:30px">
                    <label>Available time:</label>
                    <div class="season-product-available-time" style="margin-top:15px; display:flex">
                        <div class="season-product-available-time-from" style="display:flex;align-items:center">
                            <label>From: </label>
                            <input name="time-range-from" class="product-availability-timedatepicker" type="text" value="<?php echo $timeRangeFrom !== '' ? $timeRangeFrom : '00:00' ?>"/>
                        </div>
                        <div class="season-product-available-time-to" style="margin-left:30px">
                            <label>To:</label>
                            <input name="time-range-to" class="product-availability-timedatepicker" type="text" value="<?php echo $timeRangeTo !== '' ? $timeRangeTo : '23:59' ?>"/>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="wp-product-avaiable">
            <b>Product lead time:</b>
            <div class="wp-product-lead-time">
                <div class="lead-time-row">
                    <input type="radio" name="product-lead-time-checkbox" value="same"
                    <?php echo $productLeadTime[0] !== 'advance' ? 'checked' : '' ?>> Same day product
                    <span>
                        Leadtime for order: <input type="number" name="product-lead-time-minutes" min="0" max="9999" value="<?php echo $leadTimeMinutes[0] ?>" placeholder="minutes"> minutes
                    </span>
                </div>
                <div class="lead-time-row">
                    <input type="radio" name="product-lead-time-checkbox" value="advance"
                    <?php echo $productLeadTime[0] === 'advance' ? 'checked' : '' ?>> Advance product
                    <span>
                        Leadtime for order: <input type="number" name="product-lead-time-days" min="0" max="9999" value="<?php echo $leadTimeDays[0] ?>" placeholder="day(s)"> day(s)
                    </span>
                </div>
            </div>
        </div>
        <div class="wp-product-avaiable">
            <b>Delivery method:</b>
            <div class="wp-product-delivery-method">
                <div>
                    <input type="radio" name="delivery_method" value="both" checked> Both Delivery and Self-collect
                </div>
                <div>
                    <input type="radio" name="delivery_method" value="delivery"
                    <?php echo $deliveryMethod[0] === 'delivery' ? 'checked' : '' ?>> Only Delivery
                </div>
                <div>
                    <input type="radio" name="delivery_method" value="self"
                    <?php echo $deliveryMethod[0] === 'self' ? 'checked' : '' ?>> Only Self-collect
                </div>
            </div>
        </div>
        <div class="wp-product-avaiable wp-product-store-location">
            <b>Product available for location:</b>
            <div class="wp-product-list-location">
                <?php
                    if(!empty($list_option_stores)):
                        $checkall = false;
                        if (empty($deliveryMethod[0]))
                            $checkall = true
                ?>
                <div class="wp-product-location">
                    <input type="checkbox" class="wp-product-checkbox-all" <?php echo $checkall ? 'checked' : '' ?>>
                    <span>all locations</span>
                </div>
                <?php foreach ($list_option_stores as $key => $store):
                    $exist = filter_array($list_stores, 'store_id', $store['id']);
                ?>
                    <div class="wp-product-location">
                        <input type="checkbox" class="wp-product-checkbox" name="product_stores[]"
                        <?php echo !empty($exist) || $checkall ? 'checked' : '' ?>
                        value="<?php echo $store['id']; ?>"
                        >
                        <span><?php echo $store['store_name']; ?></span>
                    </div>
                <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    <?php
}

add_action( 'add_meta_boxes', 'additional_product_tabs_metabox' );

function save_data_custom_meta_box( $post_id) {
    $daily_product_from_string = 'daily-product-available-time-from';
    $daily_product_to_string = 'daily-product-available-time-to';
    $date_range_from = 'date-range-from';
    $date_range_to = 'date-range-to';
    $time_range_from = 'time-range-from';
    $time_range_to = 'time-range-to';
    $type_choosen = 'type-choosen';

    $delivery_method = 'delivery_method';
    $product_stores = 'product_stores';

    $listDay = [
        'monday' => __('Monday', 'woocommerce'),
        'tuesday' => __('Tuesday', 'woocommerce'),
        'wednesday' => __('Wednesday', 'woocommerce'),
        'thursday' => __('Thursday', 'woocommerce'),
        'friday' => __('Friday', 'woocommerce'),
        'saturday' => __('Saturday', 'woocommerce'),
        'sunday' => __('Sunday', 'woocommerce'),
    ];

    $product_stores = isset($_POST[$product_stores]) ? $_POST[$product_stores] : [];
    update_post_meta($post_id, $delivery_method, $_POST[$delivery_method]);
    // update table holiday store
    require_once __DIR__ . '/store_location.php';
    
    $list_stores = get_list_stores($post_id);

    if ($_POST[$delivery_method] !== 'delivery') {
        delete_option_stores($post_id);
        multiple_insert_store_post($list_stores, $post_id, $product_stores);
    }

    // product lead time
    $leadTimeCheckbox = 'product-lead-time-checkbox';
    $leadTimeMinutes = 'product-lead-time-minutes';
    $leadTimeDays = 'product-lead-time-days';
    update_post_meta($post_id, $leadTimeCheckbox, $_POST[$leadTimeCheckbox]);
    update_post_meta($post_id, $leadTimeMinutes, intval($_POST[$leadTimeMinutes]));
    update_post_meta($post_id, $leadTimeDays, intval($_POST[$leadTimeDays]));

    if (array_key_exists($type_choosen, $_POST) && $_POST['type-choosen'] === 'daily-product') {
        update_post_meta(
            $post_id,
            '_type',
            $_POST['type-choosen']
        );
        // save
        foreach ($listDay as $key => $value) {
            if (isset($_POST[$key])) {
                update_post_meta( $post_id, $key, 'yes' );
            } else {
                update_post_meta( $post_id, $key, 'no' );
            }
        }

        if (array_key_exists($daily_product_from_string, $_POST)) {
            update_post_meta(
                $post_id,
                $daily_product_from_string,
                $_POST[$daily_product_from_string]
            );
        }
    
        if (array_key_exists($daily_product_to_string, $_POST)) {
            update_post_meta(
                $post_id,
                $daily_product_to_string,
                $_POST[$daily_product_to_string]
            );
        }

        // == remove

        delete_post_meta(
            $post_id,
            $date_range_from,
        );

        delete_post_meta(
            $post_id,
            $time_range_from,
        );

        delete_post_meta(
            $post_id,
            $time_range_to,
        );
    
        delete_post_meta(
            $post_id,
            $date_range_to,
        );
    
        delete_post_meta(
            $post_id,
            'one-day-date-picker',
        );
    
        delete_post_meta(
            $post_id,
            'one-day-time-to',
        );
    
        delete_post_meta(
            $post_id,
            'one-day-time-from',
        );
    };

    if (array_key_exists($type_choosen, $_POST) && $_POST['type-choosen'] === 'season-product-one-day-only') {
        update_post_meta(
            $post_id,
            '_type',
            $_POST['type-choosen']
        );
        if (array_key_exists('one-day-date-picker', $_POST)) {
            update_post_meta(
                $post_id,
                'one-day-date-picker',
                $_POST['one-day-date-picker']
            );
        }

        if (array_key_exists('one-day-time-to', $_POST)) {
            update_post_meta(
                $post_id,
                'one-day-time-to',
                $_POST['one-day-time-to']
            );
        }

        if (array_key_exists('one-day-time-from', $_POST)) {
            update_post_meta(
            $post_id,
                'one-day-time-from',
                $_POST['one-day-time-from']
            );
        }

        //remove

        foreach ($listDay as $key => $value) {
            update_post_meta( $post_id, $key, 'no' );
        }

        delete_post_meta(
            $post_id,
            $daily_product_from_string,
        );
    
        delete_post_meta(
            $post_id,
            $daily_product_to_string,
        );

        delete_post_meta(
            $post_id,
            $date_range_from,
        );

        delete_post_meta(
            $post_id,
            $date_range_to,
        );

        delete_post_meta(
            $post_id,
            $time_range_from,
        );

        delete_post_meta(
            $post_id,
            $time_range_to,
        );
    }

    if (array_key_exists($type_choosen, $_POST) && $_POST['type-choosen'] === 'season-product-date-range') {
        update_post_meta(
            $post_id,
            '_type',
            $_POST['type-choosen']
        );
        if (array_key_exists($date_range_from, $_POST)) {
            update_post_meta(
                $post_id,
                $date_range_from,
                $_POST[$date_range_from]
            );
        };

        if (array_key_exists($date_range_to, $_POST)) {
            update_post_meta(
                $post_id,
                $date_range_to,
                $_POST[$date_range_to]
            );
        };

        if (array_key_exists($time_range_from, $_POST)) {
            update_post_meta(
                $post_id,
                $time_range_from,
                $_POST[$time_range_from]
            );
        };

        if (array_key_exists($time_range_to, $_POST)) {
            update_post_meta(
                $post_id,
                $time_range_to,
                $_POST[$time_range_to]
            );
        };

        foreach ($listDay as $key => $value) {
            update_post_meta( $post_id, $key, 'no' );
        }

        delete_post_meta(
            $post_id,
            $daily_product_from_string,
        );
    
        delete_post_meta(
            $post_id,
            $daily_product_to_string,
        );

        delete_post_meta(
            $post_id,
            'one-day-date-picker',
        );

        delete_post_meta(
            $post_id,
            'one-day-time-to',
        );

        delete_post_meta(
            $post_id,
            'one-day-time-from',
        );
    }
}
add_action('save_post', 'save_data_custom_meta_box');

function custom_js_product_avalability( $hook ) {
    wp_enqueue_script('jquery');
    wp_enqueue_style('pa-timepicker-css', get_template_directory_uri() . '/css/jquery.datetimepicker.css');
    wp_enqueue_script('pa-timepicker-js', get_template_directory_uri() . '/js/jquery.datetimepicker.full.js');
    wp_enqueue_style('pa-storecss', get_template_directory_uri() . '/css/product-availability.css');
    wp_enqueue_script('pa-storejs', get_template_directory_uri() . '/js/product-availability.js');
    ?>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            if (document.getElementById('type-choosen').value === 'daily-product') {
                document.getElementById('one-day-date-picker').removeAttribute('required');
                document.getElementById('date-range-from').removeAttribute('required');
                document.getElementById('date-range-to').removeAttribute('required');
                document.getElementById('daily-product').checked = true;
                document.getElementById('season-product').checked = false;
                document.getElementById('type-choosen').value = 'daily-product';
                document.getElementsByClassName('season-product-info')[0].style.display = 'none';
                document.getElementsByClassName('daily-product-info')[0].style.display = 'block';
            } else if (document.getElementById('type-choosen').value === 'season-product-one-day-only') {
                document.getElementById('daily-product').checked = false;
                document.getElementById('season-product').checked = true;
                document.getElementsByClassName('daily-product-info')[0].style.display = 'none';
                document.getElementById('one-day-date-picker').setAttribute('required', 'required');
                document.getElementById('date-range-from').removeAttribute('required');
                document.getElementById('date-range-to').removeAttribute('required');
                document.getElementsByClassName('date-range-from')[0].style.display = 'none';
                document.getElementsByClassName('date-range-to')[0].style.display = 'none';
                document.getElementsByClassName('season-product-available-time-range')[0].style.display = 'none';
                document.getElementById('one-day-only').selected = "true";
            } else {
                document.getElementById('daily-product').checked = false;
                document.getElementById('season-product').checked = true;
                document.getElementsByClassName('daily-product-info')[0].style.display = 'none';
                document.getElementById('one-day-date-picker').removeAttribute('required', 'required');
                document.getElementById('date-range-from').setAttribute('required', 'required');
                document.getElementById('date-range-to').setAttribute('required', 'required');
                document.getElementById('one-day-date-picker').style.display = 'none';
                document.getElementsByClassName('season-product-available-time-range')[0].style.display = 'block';
                document.getElementsByClassName('season-product-available-one-day')[0].style.display = 'none';
                document.getElementsByClassName('date-range-from')[0].style.display = 'block';
                document.getElementsByClassName('date-range-to')[0].style.display = 'block';
                document.getElementById('time-range').selected = "true";
            }
            document.getElementById('one-day-date-picker').removeAttribute('required');
            document.getElementById('date-range-from').removeAttribute('required');
            document.getElementById('date-range-to').removeAttribute('required');
        });
        function checkDailyProduct() {
            document.getElementById('one-day-date-picker').removeAttribute('required');
            document.getElementById('date-range-from').removeAttribute('required');
            document.getElementById('date-range-to').removeAttribute('required');
            document.getElementById('type-choosen').value = 'daily-product';
            document.getElementsByClassName('season-product-info')[0].style.display = 'none';
            document.getElementsByClassName('daily-product-info')[0].style.display = 'block';
        };

        function checkSeasonProduct() {
            document.getElementById('one-day-date-picker').setAttribute('required', 'required');
            document.getElementById('date-range-from').removeAttribute('required');
            document.getElementById('date-range-to').removeAttribute('required');
            document.getElementById('type-choosen').value = 'season-product-one-day-only';
            document.getElementsByClassName('season-product-info')[0].style.display = 'block';
            document.getElementsByClassName('daily-product-info')[0].style.display = 'none';

            const value = document.getElementById('season-product-list-date-available-select').value;
            if (value === 'one-day-only') {
                document.getElementById('one-day-date-picker').setAttribute('required', 'required');
                document.getElementById('date-range-from').removeAttribute('required');
                document.getElementById('date-range-to').removeAttribute('required');
                document.getElementById('type-choosen').value = 'season-product-one-day-only';
                document.getElementsByClassName('date-range-from')[0].style.display = 'none';
                document.getElementsByClassName('date-range-to')[0].style.display = 'none';
                document.getElementsByClassName('season-product-available-time-range')[0].style.display = 'none';
            } else {
                document.getElementById('one-day-date-picker').removeAttribute('required', 'required');
                document.getElementById('date-range-from').setAttribute('required');
                document.getElementById('date-range-to').setAttribute('required');
                document.getElementById('type-choosen').value = 'season-product-date-range';
                document.getElementsByClassName('season-product-available-one-day')[0].style.display = 'none';
                document.getElementsByClassName('date-range-from')[0].style.display = 'block';
                document.getElementsByClassName('date-range-to')[0].style.display = 'block';
            }
        };

        function handleChangeType(data) {
            if (data.value === 'time-range') {
                document.getElementById('one-day-date-picker').removeAttribute('required', 'required');
                document.getElementById('date-range-from').setAttribute('required', 'required');
                document.getElementById('date-range-to').setAttribute('required', 'required');
                document.getElementById('type-choosen').value = 'season-product-date-range';
                document.getElementById('one-day-date-picker').style.display = 'none';
                document.getElementsByClassName('season-product-available-time-range')[0].style.display = 'block';
                document.getElementsByClassName('season-product-available-one-day')[0].style.display = 'none';
                document.getElementsByClassName('date-range-from')[0].style.display = 'block';
                document.getElementsByClassName('date-range-to')[0].style.display = 'block';
            } else {
                document.getElementById('one-day-date-picker').setAttribute('required', 'required');
                document.getElementById('date-range-from').removeAttribute('required');
                document.getElementById('date-range-to').removeAttribute('required');
                document.getElementById('type-choosen').value = 'season-product-one-day-only';
                document.getElementById('one-day-date-picker').style.display = 'block';
                document.getElementsByClassName('season-product-available-time-range')[0].style.display = 'none';
                document.getElementsByClassName('season-product-available-one-day')[0].style.display = 'block';
                document.getElementsByClassName('date-range-from')[0].style.display = 'none';
                document.getElementsByClassName('date-range-to')[0].style.display = 'none';
            }
        }

        function checkDailyProductVariation(loop) {
            document.getElementById(`daily-product-info-variations[${loop}]`).style.display = 'block';
            document.getElementById(`season-product-info-variations[${loop}]`).style.display = 'none';
            document.getElementById(`type-choosen-variation[${loop}]`).value = 'daily-product-variation';
        }

        function checkSeasonProductVariation(loop) {
            document.getElementById(`daily-product-info-variations[${loop}]`).style.display = 'none';
            document.getElementById(`season-product-info-variations[${loop}]`).style.display = 'block';
            document.getElementsByClassName(`date-range-from-variations[${loop}]`)[0].style.display = 'none';
            document.getElementsByClassName(`date-range-to-variations[${loop}]`)[0].style.display = 'none';
            document.getElementById(`type-choosen-variation[${loop}]`).value = 'season-product-one-day-only-variation';
            const value = document.getElementById(`season-product-list-date-available-select-variations[${loop}]`).value;

            if (value === 'one-day-only-variations') {
                document.getElementsByClassName(`season-product-available-time-range-variations[${loop}]`)[0].style.display = 'none';
                document.getElementById(`one-day-date-picker-variations[${loop}]`).style.display = 'block';
                document.getElementsByClassName(`date-range-from-variations[${loop}]`)[0].style.display = 'none';
                document.getElementById(`type-choosen-variation[${loop}]`).value = 'season-product-one-day-only-variation';
                document.getElementsByClassName(`date-range-to-variations[${loop}]`)[0].style.display = 'none';
            } else {
                document.getElementById(`one-day-date-picker-variations[${loop}]`).style.display = 'none';
                document.getElementsByClassName(`date-range-from-variations[${loop}]`)[0].style.display = 'block';
                document.getElementsByClassName(`date-range-to-variations[${loop}]`)[0].style.display = 'block';
                document.getElementsByClassName(`season-product-available-time-range-variations[${loop}]`)[0].style.display = 'block';
                document.getElementById(`type-choosen-variation[${loop}]`).value = 'season-product-date-range-variation';
            }
        }

        function handleChangeTypeVariation(data, loop) {
            if (data.value == 'one-day-only-variations') {
                document.getElementById(`one-day-date-picker-variations[${loop}]`).style.display = 'block';
                document.getElementsByClassName(`date-range-from-variations[${loop}]`)[0].style.display = 'none';
                document.getElementsByClassName(`date-range-to-variations[${loop}]`)[0].style.display = 'none';
                document.getElementsByClassName(`season-product-available-one-day-variations[${loop}]`)[0].style.display = 'block';
                document.getElementsByClassName(`season-product-available-time-range-variations[${loop}]`)[0].style.display = 'none';
                document.getElementById(`type-choosen-variation[${loop}]`).value = 'season-product-one-day-only-variation';
            } else {
                document.getElementById(`type-choosen-variation[${loop}]`).value = 'season-product-date-range-variation';
                document.getElementById(`one-day-date-picker-variations[${loop}]`).style.display = 'none';
                document.getElementsByClassName(`date-range-from-variations[${loop}]`)[0].style.display = 'block';
                document.getElementsByClassName(`date-range-to-variations[${loop}]`)[0].style.display = 'block';
                document.getElementsByClassName(`season-product-available-one-day-variations[${loop}]`)[0].style.display = 'none';
                document.getElementsByClassName(`season-product-available-time-range-variations[${loop}]`)[0].style.display = 'block';
            }
        }
    </script>
    <?php
}


add_action('woocommerce_after_main_content', 'show_welcome', 50);
function show_welcome() {
    if (is_home()) {
        get_template_part('welcome-templates/welcome', 'main');
    }
}

add_action('admin_enqueue_scripts', 'custom_js_product_avalability');

add_action( 'woocommerce_save_product_variation', 'add_variation_product_availability', 10, 2 );

add_action( 'wp_enqueue_scripts', 'add_css_custom' );

function add_css_custom() {
    wp_enqueue_style('home-page', get_stylesheet_directory_uri() . '/style.css');
}

function add_variation_product_availability( $variation_id, $i ) {
    $listDay = [
        'monday_variation' => __('Monday', 'woocommerce'),
        'tuesday_variation' => __('Tuesday', 'woocommerce'),
        'wednesday_variation' => __('Wednesday', 'woocommerce'),
        'thursday_variation' => __('Thursday', 'woocommerce'),
        'friday_variation' => __('Friday', 'woocommerce'),
        'saturday_variation' => __('Saturday', 'woocommerce'),
        'sunday_variation' => __('Sunday', 'woocommerce'),
    ];

    if ($_POST['type-choosen-variation'][$i] === 'season-product-date-range-variation') {
        update_post_meta(
            $variation_id,
            '_type',
            $_POST['type-choosen-variation'][$i]
        );
        if (array_key_exists('date-range-from-variations', $_POST)) {
            update_post_meta(
                $variation_id,
                '_date_range_from_variation',
                $_POST['date-range-from-variations'][$i]
            );
        };
        
        if (array_key_exists('date-range-to-variations', $_POST)) {
            update_post_meta(
                $variation_id,
                '_date_range_to_variation',
                $_POST['date-range-to-variations'][$i]
            );
        };

        if (array_key_exists('time-range-from-variations', $_POST)) {
            update_post_meta(
                $variation_id,
                '_time_range_from_variation',
                $_POST['time-range-from-variations'][$i]
            );
        };

        if (array_key_exists('time-range-to-variations', $_POST)) {
            update_post_meta(
                $variation_id,
                '_time_range_to_variation',
                $_POST['time-range-to-variations'][$i]
            );
        };
        
        foreach ($listDay as $key => $value) {
            update_post_meta( $variation_id, $key, 'no' );
        }

        delete_post_meta(
            $variation_id,
            '_daily_product_available_time_from_variation',
        );
    
        delete_post_meta(
            $variation_id,
            '_daily_product_available_time_to_variation',
        );

        delete_post_meta(
            $variation_id,
            '_one_day_date_picker_variation',
        );

        delete_post_meta(
            $variation_id,
            '_one_day_time_from_variation',
        );

        delete_post_meta(
            $variation_id,
            '_one_day_time_to_variation',
        );
    } else if ($_POST['type-choosen-variation'][$i] === 'season-product-one-day-only-variation') {
        update_post_meta(
            $variation_id,
            '_type',
            $_POST['type-choosen-variation'][$i]
        );
        if (array_key_exists('one-day-date-picker-variations', $_POST)) {
            update_post_meta(
                $variation_id,
                '_one_day_date_picker_variation',
                $_POST['one-day-date-picker-variations'][$i]
            );
        }

        if (array_key_exists('one-day-time-to-variations', $_POST)) {
            update_post_meta(
                $variation_id,
                '_one_day_time_to_variation',
                $_POST['one-day-time-to-variations'][$i]
            );
        }
        
        if (array_key_exists('one-day-time-from-variations', $_POST)) {
            update_post_meta(
                $variation_id,
                '_one_day_time_from_variation',
                $_POST['one-day-time-from-variations'][$i]
            );
        }

        //remove

        foreach ($listDay as $key => $value) {
            update_post_meta( $variation_id, $key, 'no' );
        }

        delete_post_meta(
            $variation_id,
            '_daily_product_available_time_from_variation',
        );
    
        delete_post_meta(
            $variation_id,
            '_daily_product_available_time_to_variation',
        );

        delete_post_meta(
            $variation_id,
            '_date_range_from_variation',
        );
        
        delete_post_meta(
            $variation_id,
            '_date_range_to_variation',
        );

        delete_post_meta(
            $variation_id,
            '_time_range_from_variation',
        );
        
        delete_post_meta(
            $variation_id,
            '_time_range_to_variation',
        );
    } else {
        foreach ($listDay as $key => $value) {
            if (isset($_POST[$key][$i])) {
                update_post_meta( $variation_id, $key, 'yes' );
            } else {
                update_post_meta( $variation_id, $key, 'no' );
            }
        }

        update_post_meta(
            $variation_id,
            '_type',
            $_POST['type-choosen-variation'][$i]
        );

        if (array_key_exists('daily-product-available-time-from-variation', $_POST)) {
            update_post_meta(
                $variation_id,
                '_daily_product_available_time_from_variation',
                $_POST['daily-product-available-time-from-variation'][$i]
            );
        }
    
        if (array_key_exists('daily-product-available-time-to-variation', $_POST)) {
            update_post_meta(
                $variation_id,
                '_daily_product_available_time_to_variation',
                $_POST['daily-product-available-time-to-variation'][$i]
            );
        }
        
        delete_post_meta(
            $variation_id,
            '_date_range_from_variation',
        );
        
        delete_post_meta(
            $variation_id,
            '_date_range_to_variation',
        );

        delete_post_meta(
            $variation_id,
            '_time_range_from_variation',
        );
        
        delete_post_meta(
            $variation_id,
            '_time_range_to_variation',
        );

        delete_post_meta(
            $variation_id,
            '_one_day_date_picker_variation',
        );

        delete_post_meta(
            $variation_id,
            '_one_day_time_from_variation',
        );

        delete_post_meta(
            $variation_id,
            '_one_day_time_to_variation',
        );
    }
}
